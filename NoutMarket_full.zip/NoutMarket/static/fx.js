/*fx*/
(function(){
const ok=[],T=(n,f)=>{try{f();ok.push(n)}catch(e){}},$=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const fine=window.matchMedia&&matchMedia('(hover:hover) and (pointer:fine)').matches,still=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches;
T('intro',()=>{const d=document.createElement('div');d.id='pt';d.innerHTML='<i></i>';document.body.appendChild(d);
  document.addEventListener('click',e=>{const a=e.target.closest&&e.target.closest('a[href]');if(!a||a.target||e.defaultPrevented||e.metaKey||e.ctrlKey)return;const h=a.getAttribute('href');
    if(!h||h[0]==='#'||/^(https?:|mailto:|tel:)/.test(h)||h.indexOf('#')===0||!/(\.html|\/)(#.*)?$|^\/(pc|catalog|admin)?$/.test(h))return;
    e.preventDefault();d.classList.add('go');setTimeout(()=>{location.href=a.href},260)});
  addEventListener('pageshow',()=>d.classList.remove('go'))});
T('progress',()=>{const b=document.createElement('div');b.id='sp';document.body.appendChild(b);const hd=$('header');
  const f=()=>{const h=document.documentElement.scrollHeight-innerHeight;b.style.transform='scaleX('+(h>0?Math.min(1,scrollY/h):0)+')';if(hd)hd.classList.toggle('sc',scrollY>30)};addEventListener('scroll',f,{passive:true});f()});
T('glow',()=>{if(!fine)return;const g=document.createElement('div');g.id='glow';document.body.insertBefore(g,document.body.firstChild);
  addEventListener('pointermove',e=>{g.style.setProperty('--mx',e.clientX+'px');g.style.setProperty('--my',e.clientY+'px')},{passive:true})});
T('reveal',()=>{const els=$$('.sec,.trust>div,.ct>div,.cta h2,.cta a,.hero,.stats>div,.tile,.marq,.master,.ctl');els.forEach((e,i)=>{e.classList.add('rv');e.style.setProperty('--d',(i%4)*90+'ms')});
  if(!('IntersectionObserver'in window)||still){els.forEach(e=>e.classList.add('in'));return}
  const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.12});els.forEach(e=>io.observe(e))});
T('count',()=>{const els=$$('[data-count]');if(!els.length)return;const run=e=>{const n=+e.dataset.count,t0=performance.now();(function f(t){const k=Math.min(1,(t-t0)/1400);e.textContent=Math.round(n*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(f)})(t0)};
  if(!('IntersectionObserver'in window)){els.forEach(run);return}const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){run(x.target);io.unobserve(x.target)}}),{threshold:.6});els.forEach(e=>io.observe(e))});
T('magnet',()=>{if(!fine||still)return;document.addEventListener('pointermove',e=>{const b=e.target.closest&&e.target.closest('.btn,.chip');if(!b)return;const r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.18)+'px,'+((e.clientY-r.top-r.height/2)*.28)+'px)'});
  document.addEventListener('pointerout',e=>{const b=e.target.closest&&e.target.closest('.btn,.chip');if(b&&!b.contains(e.relatedTarget))b.style.transform=''})});
T('tiles',()=>{$$('.tile').forEach(t=>t.addEventListener('pointermove',e=>{const r=t.getBoundingClientRect();t.style.setProperty('--x',(e.clientX-r.left)+'px');t.style.setProperty('--y',(e.clientY-r.top)+'px')}))});
T('letters',()=>{const h=$('.cap h2');if(!h||still)return;const s=h.textContent;h.setAttribute('aria-label',s);h.innerHTML=[...s].map((c,i)=>'<span aria-hidden="true" style="--i:'+i+'">'+(c===' '?'&nbsp;':c)+'</span>').join('')});
T('scroll-hint',()=>{const s=$('.stk');if(!s||!$('.cap'))return;const d=document.createElement('div');d.className='scrl';d.setAttribute('aria-hidden','true');s.appendChild(d)});
T('particles',()=>{const s=$('.stk'),m=$('#s3d');if(!s||!m||still)return;const c=document.createElement('canvas');c.id='pfx';s.insertBefore(c,m);const x=c.getContext('2d');let W,H,P=[];
  const rs=()=>{W=c.width=s.clientWidth;H=c.height=s.clientHeight;P=Array.from({length:Math.min(70,Math.round(W*H/16000))},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.25,vy:-.1-Math.random()*.3,r:1+Math.random()*1.8,h:Math.random()}))};rs();addEventListener('resize',rs);
  (function f(){if(!c.isConnected)return;const b=s.getBoundingClientRect();if(b.bottom>0&&b.top<innerHeight&&!document.hidden){x.clearRect(0,0,W,H);
    P.forEach(p=>{p.x+=p.vx;p.y+=p.vy;if(p.y<-5){p.y=H+5;p.x=Math.random()*W}if(p.x<-5)p.x=W+5;if(p.x>W+5)p.x=-5;x.fillStyle=p.h>.5?'rgba(240,171,252,.8)':'rgba(34,211,238,.7)';x.beginPath();x.arc(p.x,p.y,p.r,0,6.3);x.fill()});
    x.lineWidth=.6;for(let i=0;i<P.length;i++)for(let j=i+1;j<P.length;j++){const dx=P[i].x-P[j].x,dy=P[i].y-P[j].y,d=dx*dx+dy*dy;if(d<12000){x.strokeStyle='rgba(160,140,255,'+(.22*(1-d/12000))+')';x.beginPath();x.moveTo(P[i].x,P[i].y);x.lineTo(P[j].x,P[j].y);x.stroke()}}}
    requestAnimationFrame(f)})()});
window.__fx=ok;
})();

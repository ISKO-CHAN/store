// Просмотр 3D-модели игрового ноутбука ASUS ROG (GLB встроен в rog_model.js)
window.rogViewer=function(el,opt){
  opt=opt||{};const T=THREE;
  if(!T.GLTFLoader||!window.ROG_GLB){el.textContent='3D недоступно';return}
  const W0=el.clientWidth||300,H0=el.clientHeight||300;
  const r=new T.WebGLRenderer({antialias:true,alpha:true});r.setPixelRatio(Math.min(devicePixelRatio,opt.maxPR||1.75));r.setSize(W0,H0);r.outputEncoding=T.sRGBEncoding;el.appendChild(r.domElement);
  const sc=new T.Scene(),cam=new T.PerspectiveCamera(32,W0/H0,.1,100);
  sc.add(new T.HemisphereLight(0xffffff,0x445066,.9));const dl=new T.DirectionalLight(0xffffff,1.1);dl.position.set(4,7,5);sc.add(dl);
  const p1=new T.PointLight(0xff3b7a,1.4,30);p1.position.set(-5,2,3);sc.add(p1);const p2=new T.PointLight(0x6d5bff,1.2,30);p2.position.set(5,3,-2);sc.add(p2);if(opt.accent)p1.color.set(opt.accent);
  const root=new T.Group();sc.add(root);
  let rings=[],pts=null,pa=null;
  if(opt.fx){[3.0,3.7].forEach((rad,i)=>{const m=new T.Mesh(new T.TorusGeometry(rad,.014,8,120),new T.MeshBasicMaterial({color:i?0x22d3ee:0xff3b7a,transparent:true,opacity:.6}));m.rotation.x=Math.PI/2;m.position.y=.02;root.add(m);rings.push(m)});
    const N=140,arr=new Float32Array(N*3);for(let i=0;i<N;i++){const a=Math.random()*6.283,rr=1.2+Math.random()*3.2;arr[i*3]=Math.cos(a)*rr;arr[i*3+1]=Math.random()*4;arr[i*3+2]=Math.sin(a)*rr}
    const gp=new T.BufferGeometry();gp.setAttribute('position',new T.BufferAttribute(arr,3));pts=new T.Points(gp,new T.PointsMaterial({color:0xffb3dc,size:.06,transparent:true,opacity:.85,depthWrite:false}));root.add(pts);pa=arr}
  const sh=document.createElement('canvas');sh.width=sh.height=128;{const x=sh.getContext('2d'),q=x.createRadialGradient(64,64,6,64,64,64);q.addColorStop(0,'rgba(0,0,0,.55)');q.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=q;x.fillRect(0,0,128,128)}
  const shadow=new T.Mesh(new T.PlaneGeometry(8,6),new T.MeshBasicMaterial({map:new T.CanvasTexture(sh),transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=-.01;root.add(shadow);
  let lid=null,base=0,glow=null,ready=false,mx=0,t0=performance.now();
  const bin=atob(window.ROG_GLB),buf=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)buf[i]=bin.charCodeAt(i);
  new T.GLTFLoader().parse(buf.buffer,'',gltf=>{
    const m=gltf.scene;
    m.traverse(o=>{if(o.isMesh){o.frustumCulled=false;(Array.isArray(o.material)?o.material:[o.material]).forEach(x=>{if(x.name==='Glow')glow=x;if(x.name==='Acer-Logo_2011'&&opt.brand&&opt.brand!=='ASUS')o.visible=false})}});
    lid=m.getObjectByName('Screen');base=lid?lid.rotation.x:0;
    m.updateMatrixWorld(true);const bb=new T.Box3().setFromObject(m),sz=bb.getSize(new T.Vector3()),c=bb.getCenter(new T.Vector3()),s=4.4/sz.x;
    m.scale.setScalar(s);m.position.set(-c.x*s,-bb.min.y*s,-c.z*s);root.add(m);ready=true;t0=performance.now();
  },()=>{el.textContent='Не удалось загрузить 3D'});
  el.addEventListener('pointermove',e=>{mx=e.offsetX/(el.clientWidth||1)-.5});
  addEventListener('resize',()=>{if(!el.isConnected)return;r.setSize(el.clientWidth,el.clientHeight);cam.aspect=el.clientWidth/el.clientHeight;cam.updateProjectionMatrix()});
  (function f(){
    if(!el.isConnected){r.dispose();return}
    const t=(performance.now()-t0)/1000;
    if(ready){
      const o=Math.min(1,t/1.8),e=o<.5?4*o*o*o:1-Math.pow(-2*o+2,3)/2;if(lid)lid.rotation.x=base*e;
      root.rotation.y=Math.sin(t*.5)*.6+mx*.9;root.position.y=Math.sin(t*1.1)*.04;
      if(glow)glow.emissive.setHSL((t*.12)%1,1,.5);
    }
    rings.forEach((m,i)=>{m.scale.setScalar(1+.05*Math.sin(t*1.8+i));m.material.opacity=.35+.3*Math.sin(t*2+i*2)});
    if(pa){for(let i=1;i<pa.length;i+=3){pa[i]+=.012;if(pa[i]>4.2)pa[i]=0}pts.geometry.attributes.position.needsUpdate=true}
    const d=Math.max(opt.dist||8.4,9.5/cam.aspect);cam.position.set(0,3,d);cam.lookAt(0,1.2,0);
    r.render(sc,cam);requestAnimationFrame(f)})();
};
